<?php
include 'connect.php';
$id=$_GET['updateid'];
$sql="select * from lovely where id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
     $name=$row['name'];
     $email=$row['email'];
     $phone=$row['phone'];
     $password=$row['password'];
if(isset($_POST['submit'])){
      $name=$_POST['name'];
      $email=$_POST['email'];
      $phone=$_POST['phone'];
      $password=$_POST['password'];

$sql="update lovely set  name='$name' , email='$email', phone=$phone, password='$password' 
where id=$id ";
     
      $result=mysqli_query($con,$sql);
      if($result){
             
            // echo" update successfully";
            header('location:display.php');
      }else{
            die(mysqli_error($con));
      } 
      }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>curd</title>
</head>
<body>
    <div class="container">
        <form method="post">
            

          <div class="form group">
                <label> name </label>
                <input type="text" class="form-control"
                placeholder="enter your name"
                name="name" value=<?php echo $name;?>>
          </div>
          <div class="form group">
                <label> email</label>
                <input type="text" class="form-control"
                placeholder="enter your email"
                name="email" value=<?php echo $email;?>>
          </div>

          <div class="form group">
                <label> phone </label>
                <input type="text" class="form-control"
                placeholder="enter your name"
                name="phone" value=<?php echo $phone;?>>
          </div>
          <div class="form group">
                <label> password</label>
                <input type="text" class="form-control"
                placeholder="enter your name"
                name="password" value=<?php echo $password;?>>
          </div>
            <button type="submit" class="btn
             btn-primary" name="submit">submit</button>
</form>
 </div>
</body>
</html>
