<?php
$con=new mysqli('localhost','root','','curd');
if(!$con){
   
    die(mysqli_error($con));
}
?>