
<?php
if(isset($_POST['submit']))
{
    $host='localhost';
    $user='root';
    $pass='';
    $dbname='project';
    $name=$_POST['name'];
    $email=$_POST['email'];
    $msg=$_POST['message'];

    $conn =mysqli_connect($host,$user,$pass,$dbname);
    if(!$conn){
        die('could not connect: '.mysqli_connect_error());
    }


    echo 'connected successfuly<br/>';


    $sql="insert into contact(Name,Email,msg)
    values('$name','$email','$msg')";
 
    if(mysqli_query($conn,$sql)){
        header("location:index.html");
        // echo "sucessfull";
    }else{
        echo "error".mysqli_error($conn);
    }
 mysqli_close($conn);
}
?>










































































